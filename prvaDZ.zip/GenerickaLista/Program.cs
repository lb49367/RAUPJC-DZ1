﻿using GenerickaLista;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    class Program
    {
        static void Main(string[] args)
        {
            GenerickaLista.GenericList.Add(1); // [1]
            GenericList.Add(2); // [1 ,2]
            GenericList.Add(3); // [1 ,2 ,3]
            GenericList.Add(4); // [1 ,2 ,3 ,4]
            GenericList.Add(5); // [1 ,2 ,3 ,4 ,5]
            GenericList.RemoveAt(0); // [2 ,3 ,4 ,5]
            GenericList.Remove(5); [2 ,3 ,4]
            Console.WriteLine ( GenericList.Count ); // 3
            Console.WriteLine ( GenericList.Remove (100) ); // false
            Console.WriteLine ( GenericList.RemoveAt (5)); // false
            GenericList.Clear (); // []
            Console.WriteLine ( GenericList.Count ); // 0
        }
    }
}
