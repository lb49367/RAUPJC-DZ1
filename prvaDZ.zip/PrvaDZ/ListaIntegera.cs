﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrvaDZ
{
    public class IntegerList : IIntegerList
    {
        private int[] _internalStorage;

        private int count = 0;

        public IntegerList()
        {
            _internalStorage = new int[4];
        }

        public IntegerList(int initialSize)
        {
            if(initialSize < 0)
            {
                _internalStorage = new int[4];
            }
            _internalStorage = new int[initialSize];
        }

        public int Count
        {
            get
            {
                return this.count + 1;
            }
        }

        public void Add(int item)
        {
            if (Count > _internalStorage.Length)
            {
                Array.Resize(ref _internalStorage, 2 * (this.count));
            }
            _internalStorage[this.count] = item;
            ++this.count;
            
        }

        public void Clear()
        {

            for (int i = 0; i < _internalStorage.Length; ++i)
            {
                _internalStorage[i] = 0;
            }
        }

        public bool Contains(int item)
        {
            for (int i = 0; i < Count; ++i)
            {
                if (_internalStorage[i] == item) return true;
            }
            return false;
        }

        public int GetElement(int index)
        {
            if (index < (Count - 1))
            {
                return _internalStorage[index];
            }
            else
            {
                return 0;            }
        }

        public int IndexOf(int item)
        {
            for (int i = 0; i < Count; ++i)
            {
                if (_internalStorage[i] == item) return i;
            }
            return -1;
        }

        public bool Remove(int item)
        {
            for(int i=0; i<Count; ++i)
            {
                if (_internalStorage[i] == item)
                {
                    RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public bool RemoveAt(int index)
        {
            if(index > this.count)
            {
                return false;
            }
             else if(index==this.count)
            {
                _internalStorage[index] = 0;
                return false;
            }
            else
            {
                for(int i =index; i<Count;++i )
                {
                    _internalStorage[i] = _internalStorage[i + 1];
                }
                return true;
            }
        }
       

    }
}
